**Coudière Yves**
# Rapport TP1
## Séance 1, partie 1
 1. Je choisis d'utiliser emacs et ipython.
 2. On saute la qestion 2.
 3. Les fichiers .md contiennent du code Markdown: l'énoncé du TP pour
    README.md et le compte-rendu à produire pour CR.md. Le fichier
    img/ecran-01.png contient l'image qui est mise en référence dans
    README.md. Les fichiers .py du répertoire src/ contiennent du code
    python. Ce sont des programmes ou des éléments de programme.
## Séance 1, partie 2
 1. 
## Séance 2
