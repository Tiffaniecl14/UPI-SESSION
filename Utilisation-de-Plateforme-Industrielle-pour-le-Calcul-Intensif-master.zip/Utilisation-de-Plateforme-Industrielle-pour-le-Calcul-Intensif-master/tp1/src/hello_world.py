#! /usr/bin/env python
# -*- coding: utf-8 -*-

print("Une chaîne de caractère avec des caractères typiquement français, par exemple le symbole de l'euro, € !")
